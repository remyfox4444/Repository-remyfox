<?php

defined("DB_DRIVER") or define("DB_DRIVER", "mysql");
defined("DB_HOST") or define("DB_HOST", "127.0.0.1");
defined("DB_NAME") or define("DB_NAME", "professional");
defined("DB_USER") or define("DB_USER", "root");
defined("DB_PASSWORD") or define("DB_PASSWORD", "");