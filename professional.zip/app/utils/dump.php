<?php

function dump($var) {
    echo "<pre>";
    print_r($var);
    echo "</pre>";
    //die();
}