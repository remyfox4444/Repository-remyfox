<?php

namespace Controllers;

class Index
{
    public static function action() {
        echo 'home page';
    }
}